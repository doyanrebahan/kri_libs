class SettingsError(AttributeError):
    pass
